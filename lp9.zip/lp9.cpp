// Yuchen Shi
// ITP 365, Fall 2018
// Lab 9
// yuchensh@usc.edu
// Platform: Mac

#include <list>
#include <iostream>

void printList(const std::list<int>& myList)
{
    std::cout<<"{ ";
    for (int i : myList)
    {
        std::cout<<i<<"  ";
    }
    std::cout<<"}"<<std::endl;
}

int main()
{
    std::list<int> myList = {0, 2, 4, 6, 8, 10, 12, 14, 16, 18};
    // loop to fill myList
    std::cout<<"Beginning list..."<<std::endl;
    printList(myList);
    
    // Insert a new element at the beginning
    auto i = myList.begin();
    i=myList.insert(i, 100);
    // Now i is at the 1st element again
    std::cout<<"After insert @ begin..."<<std::endl;
    printList(myList);
    
    i++;
    i++;
    i++;
    i++;
    i=myList.insert(i, 101);
    std::cout<<"After one insert @ 1st half..."<<std::endl;
    printList(myList);
    
    i++;
    i++;
    i++;
    i++;
    i=myList.insert(i, 102);
    i++;
    i=myList.insert(i, 103);
    std::cout<<"After a double insert @ 2nd half..."<<std::endl;
    printList(myList);
    
    auto z = myList.end();
    z=myList.insert(z, 104);
    std::cout<<"After a insert @ end..."<<std::endl;
    printList(myList);
    
    auto k = myList.begin();
    k = myList.erase(k);
    std::cout<<"After a erase @ begin..."<<std::endl;
    printList(myList);
    
    k++;
    k++;
    k++;
    k=myList.erase(k);
    std::cout<<"After a erase @ 1st half..."<<std::endl;
    printList(myList);
    
    k++;
    k++;
    k++;
    k=myList.erase(k);
    k=myList.erase(k);
    std::cout<<"After a double erase @ 2nd half..."<<std::endl;
    printList(myList);
    
    auto j = myList.end();
    j--;
    // Now j is at the last element
    j = myList.erase(j);
    // j now points to the new last element
    std::cout<<"After a erase @ end..."<<std::endl;
    printList(myList);
    
    return 0;
}

