// ITP 365 Fall 2018
// LP7 – Templates
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include <iostream>
#include <vector>

template <typename T>
T averageArray(T array[], unsigned int size)
{
    T sum=0;
    for (int i=0; i<size; i++)
    {
        sum += array[i];
    }
    T average = sum/size;
    return average;
}

template <typename T>
T averageVector(std::vector<T>& myVector)
{
    T sum=0;
    for (T t:myVector)
    {
        sum += t;
    }
    T average = sum/myVector.size();
    return average;
}

template <typename T>
void displayArray(T array[], unsigned int size)
{
    for (int i=0; i<size-1; i++)
    {
        std::cout<<array[i]<<", ";
    }
    std::cout<<array[size-1]<<std::endl;
}

template <typename T>
void displayVector(std::vector<T>& myVector)
{
    for (int i=0; i<myVector.size()-1; i++)
    {
        std::cout<<myVector[i]<<", ";
    }
    std::cout<<myVector[myVector.size()-1]<<std::endl;
}


int main(int argc, const char * argv[])
{
    std::cout<<"How many numbers: ";
    unsigned int size=0;
    std::cin>>size;
    
    int* intArray = new int[size];
    double* doubleArray = new double[size];
    std::vector<int> intVector;
    std::vector<double> doubleVector;
    
    for (unsigned int i=0; i<size; i++)
    {
        intArray[i]=1+i*2;
        doubleArray[i]=1.5+i*2;
        intVector.push_back(1+i*2);
        doubleVector.push_back(1.5+i*2);
    }
    
    std::cout<<"INT Array: ";
    displayArray(intArray, size);
    std::cout<<"INT Average: "<<averageArray(intArray, size)<<std::endl;
    std::cout<<"DOUBLE Arrary: ";
    displayArray(doubleArray, size);
    std::cout<<"Double Average: "<<averageArray(doubleArray, size)<<std::endl;
    std::cout<<"INT Vector: ";
    displayVector(intVector);
    std::cout<<"INT Average: "<<averageVector(intVector)<<std::endl;
    std::cout<<"DOUBLE Vector: ";
    displayVector(doubleVector);
    std::cout<<"DOUBLE Average: "<<averageVector(doubleVector)<<std::endl;
    delete[] intArray;
    delete[] doubleArray;
    return 0;
}

