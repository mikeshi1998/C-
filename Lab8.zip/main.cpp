// ITP 365 Spring 2018
// LP8 – Timings
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include <iostream>
#include <chrono>
#include <vector>
#include <list>

int main()
{
    unsigned int stopNum = -1;
    std::cout << "Where shall I stop counting?\n> ";
    std::cin >> stopNum;
    
    std::chrono::time_point<std::chrono::system_clock> timeStart, timeEnd;
    std::chrono::duration<double> elapsedTime;
    
    std::vector<unsigned int> myVec;
    std::list<unsigned int> myList;
    
    // Counting tests
    std::cout << "Counting to " << stopNum << "... "<<std::endl;
    
    // Insert at the end of a vector
    std::cout << "Vector insert @ end... ";
    timeStart = std::chrono::system_clock::now();
    for (unsigned int i = 0; i<stopNum; i++)
    {
        myVec.push_back(i);
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Remove at the end of a vector
    std::cout << "Vector remove @ end... ";
    timeStart = std::chrono::system_clock::now();
    while (myVec.size()!=0)
    {
        myVec.pop_back();
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Insert at the beginning of a vector
    std::cout << "Vector insert @ begin... ";
    timeStart = std::chrono::system_clock::now();
    for (unsigned int i = 0; i<stopNum; i++)
    {
        myVec.insert(myVec.begin(), i);
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Remove at the beginning of a vector
    std::cout << "Vector remove @ begin... ";
    timeStart = std::chrono::system_clock::now();
    while (myVec.size()!=0)
    {
        myVec.erase(myVec.begin());
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Insert at the end of a list
    std::cout << "List insert @ end... ";
    timeStart = std::chrono::system_clock::now();
    for (unsigned int i = 0; i<stopNum; i++)
    {
        myList.push_back(i);
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Remove at the end of a list
    std::cout << "List remove @ end... ";
    timeStart = std::chrono::system_clock::now();
    while (myList.size()!=0)
    {
        myList.pop_back();
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Insert at the beginning of a list
    std::cout << "List insert @ begin... ";
    timeStart = std::chrono::system_clock::now();
    for (unsigned int i = 0; i<stopNum; i++)
    {
        myList.push_front(i);
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Remove at the beginning of a list
    std::cout << "List remove @ begin... ";
    timeStart = std::chrono::system_clock::now();
    while (myList.size()!=0)
    {
        myList.pop_front();
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    
    return 0;
}


