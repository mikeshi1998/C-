// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// ITP 365 Fall 2018
// LP3
// Platform: Mac

#include <iostream>
#include <string>
#include <fstream>
#include "map.h"


// Function: loadForum
// Purpose: load in stock exchange forum information from a file
// Input: the file to load from and the map to load it into
void loadForum(std::string& fileName, Map<std::string, std::string>& forum)
{
    std::ifstream file(fileName);
    if (file.is_open())
    {
        while (!file.eof())
        {
            // Grab each line
            std::string line;
            std::getline(file, line);
            // Find the line that has the format we want
            if (line.find(",") != std::string::npos)
            {
                // Store the string before "," as the key, and the string after "," as the value of the map
                std::string key = line.substr(0, line.find(","));
                std::string value = line.substr(line.find(",")+1);
                forum[key] = value;
            }
        }
    }
    else
    {
        error("Failed to load in file!");
    }
}


int main(int argc, char** argv)
{
	// TODO: Implement stuff
    // Create a map and load in the information from "sites.csv"
    Map<std::string, std::string> forum;
    std::string fileName = "sites.csv";
    loadForum(fileName, forum);
    
    bool quit = false;
    while (!quit)
    {
        std::cout<< "\n1) Look up forums\n2) List forum codes\n?) Quit\n> ";
        int choice;
        std::cin >> choice;
        // If input is not 1 or 2, quit the program
        if (choice != 1 && choice != 2)
        {
            quit = true;
        }
        // If input is 1, ask for forum name and print out the number of posts in the forum
        else if (choice==1)
        {
            
            std::cout<<"Enter a forum code: ";
            std::string input;
            std::cin.ignore();
            std::getline(std::cin, input);
            // Check if the forum is in our map
            if (forum.containsKey(input))
            {
                std::cout<<input<<" --> "<<forum[input]<<std::endl;
            }
            else
            {
                std::cout<<"Unknown forum."<<std::endl;
            }
        }
        // If input is 2, print out all forum names
        else if (choice==2)
        {
            std::cout<<"Forum list:"<<std::endl;
            // Use a range based for loop to get all the keys of the map
            for (std::string code : forum)
            {
                std::cout << code << std::endl;
            }
        }
    }
    std::cout<<"Bye!"<<std::endl;
	
	return 0;
}
