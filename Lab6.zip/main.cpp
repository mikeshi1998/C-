// ITP 365 Fall 2018
// LP6 -- Timings
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include <iostream>
#include <chrono>
#include "vector.h"
#include "random.h"

// Function: selectSort
// Purpose: Performs a selection sort on a vector
// Input: Vector of ints to sort (modified in function)
// Returns: Nothing
void selectSort(Vector<unsigned int>& vec);

int main(int argc, char** argv)
{
	unsigned int stopNum = 0;
	std::cout << "Where shall I stop counting?\n> ";
	std::cin >> stopNum;

	std::chrono::time_point<std::chrono::system_clock> timeStart, timeEnd;
	std::chrono::duration<double> elapsedTime;
    
    // Thing to test with
    Vector<unsigned int> myVec;
    
    // Insert at the end of empty vector
    std::cout << "Vector insert @ end of small vector...";
    timeStart = std::chrono::system_clock::now();
    for (unsigned int i = 0; i<stopNum; i++)
    {
        myVec.add(randomInteger(0, UINT_MAX));
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // std::sort on vector
    std::cout << "STD sort on vector... ";
	timeStart = std::chrono::system_clock::now();
    // This is what sorts a vector!
    std::sort(myVec.begin(), myVec.end());
	timeEnd = std::chrono::system_clock::now();
	elapsedTime = timeEnd - timeStart;
	std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Insert at the end of the same vector
    std::cout << "Vector insert @ end of large vector...";
    timeStart = std::chrono::system_clock::now();
    for (unsigned int i = 0; i<stopNum; i++)
    {
        myVec.add(randomInteger(0, UINT_MAX));
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Selection sort on vector
    std::cout << "Selection sort on vector... ";
    timeStart = std::chrono::system_clock::now();
    selectSort(myVec);
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    // Remove from the front
    std::cout << "Remove from front... ";
    timeStart = std::chrono::system_clock::now();
    while (!myVec.isEmpty())
    {
        myVec.remove(0);
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout << elapsedTime.count() << " s" << std::endl;
    
    

    return 0;
}


void selectSort(Vector<unsigned int>& vec)
{
    for (unsigned int i = 0; i<vec.size(); i++)
    {
        unsigned int smallestValue=vec[i];
        unsigned int smallestIndex=i;
        
        for (unsigned int j=i; j<vec.size(); j++)
        {
            if (vec[j]<smallestValue)
            {
                smallestValue=vec[j];
                smallestIndex=j;
            }
        }
        vec[smallestIndex] = vec[i];
        vec[i] = smallestValue;
    }
}

