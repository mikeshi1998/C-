// ITP 365 Fall 2018
// LP5 – Recursion
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: MAC

#include <iostream>

// Function: sumDigits
// Purpose: Getting the sum of the digits
// Input: An unsigned int
// Output: The sum of the digits
unsigned int sumDigits(unsigned int number)
{
    if (number < 10)
    {
        return number;
    }
    else
    {
        return number%10 + sumDigits(number/10);
    }
}

// Function: getGCD
// Purpose: Getting the greatest common denominator of two integers
// Input: Tow unsigned ints
// Output: The greatest common denominator of the two input integers
unsigned int getGCD(unsigned int x, unsigned int y)
{
    if (x%y == 0)
    {
        return y;
    }
    else
    {
        return getGCD(y, x%y);
    }
}

int main()
{
    unsigned int x;
    unsigned int y;
    std::cout<<"Gimme a number: ";
    std::cin>>x;
    std::cout<<"Gimme another number: ";
    std::cin>>y;
    std::cout<<"Sum digits ("<< x <<") = "<<sumDigits(x)<<std::endl;
    std::cout<<"Sum digits ("<< y <<") = "<<sumDigits(y)<<std::endl;
    std::cout<<"gcd("<<x<<", "<<y<<") = "<<getGCD(x, y)<<std::endl;
    return 0;
}
