// ITP 365 Fall 2018
// HW2 – itpPhone
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac
//
// PhoneSystem.cpp
// Implements PhoneSystem class
//

#include "PhoneSystem.h"
#include <fstream>


// Function: Constructor
// Purpose: Constructs two maps --
//          (1) area codes -> locations
//              (loaded from areacodes.txt)
//          (2) phone numbers -> contacts
//              (loaded from contacts.txt)
// Input: None
// Output: None
PhoneSystem::PhoneSystem()
{
	// TODO: Implement
    std::ifstream areaFile("areacodes.txt"); // Read in file
    if (areaFile.is_open())
    {
        while (!areaFile.eof())
        {
            std::string line;
            std::getline(areaFile, line);
            std::string key = line.substr(0, 3); // The first three characters are the keys
            std::string value = line.substr(4); // Characters after the fifth character are the values
            areaCodes[key]=value;
        }
    }
    else
    {
        error("Failed to load in file!");
    }
    std::ifstream contactFile("contacts.txt"); // Read in file
    if (contactFile.is_open())
    {
        while (!contactFile.eof())
        {
            std::string line;
            std::getline(contactFile, line);
            std::string key = line.substr(0, 12); // The first 12 characters are the keys
            std::string value = line.substr(13); // Characters after the fourteenth character are the values
            contactCodes[key]=value;
        }
    }
    else
    {
        error("Failed to load in file!");
    }
}

// Function: addDigit
// Purpose: Called when the user adds a digit
//          to the current phone number
// Input: Digit to add (to the end of the number)
// Output: None
void PhoneSystem::addDigit(char digit)
{
	// TODO: Implement
    if (phoneNumber.length()<12) // Do not allow the phone number to be larger than 10 digits (not including the two hyphens)
    {
        if (phoneNumber.length()==3 || phoneNumber.length()==7) // If the phoneNumber has 3 or 7 characters, add a hyphen
        {
            phoneNumber += "-";
        }
        phoneNumber += digit;
    }
    
    
}

// Function: backspace
// Purpose: Removes the rightmost digit from the number
// Input: None
// Output: None
void PhoneSystem::backspace()
{
	// TODO: Implement
    phoneNumber.pop_back();
    if (phoneNumber.length()==8 || phoneNumber.length()==4) // If the phoneNumber has 8 or 4 characters left, delete the hyphen at the end
    {
        phoneNumber.pop_back();
    }
}

// Function: getNumber
// Purpose: Returns the current number the user has dialed
// Input: None
// Output: Current number user has dialed
std::string PhoneSystem::getNumber()
{
	// TODO: Implement
	return phoneNumber;
}

// Function: lookupNumber
// Purpose: Looks up the current number in the two maps:
//          (1) First checks if this number is a contact
//          (2) Otherwise, checks if the first three digits
//              are a known area code
// Input: None
// Output: Returns a string that contains either:
//         (a) The name of the contact
//         (b) The location of the area code
//         (c) "UNKNOWN" if it's neither a contact nor
//             contains a valid area code
std::string PhoneSystem::lookupNumber()
{
	// TODO: Implement
    if (contactCodes.containsKey(phoneNumber)) // If the number is a known contact, return the name of the contact
    {
        return contactCodes[phoneNumber];
    }
    std::string areaCode=phoneNumber.substr(0, 3);
    if (areaCodes.containsKey(areaCode)) // Otherwise if the first three digits are known area codes, return the locations of the area codes
    {
        return areaCodes[areaCode];
    }
	else // If it is neither a known contact nor contains a known area code, return UNKNOWN
    {
        return "UNKNOWN";
    }
    
}
