// ITP 365 Fall 2018
// HW3 Towers of Hannoi
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include "peg.h"

 // The default constructor
Peg::Peg()
{
    mX=400;
    mY=500;
    mHeight=500;
    mWidth=100;
    mColor="black";
}

// The constructor that sets the member variable according to the input
Peg::Peg(int x, int y, int width, int height)
{
    mX=x;
    mY=y;
    mHeight=height;
    mWidth=width;
}

// Draw the peg and all the disks all this peg
void Peg::draw(GWindow& gw)
{
    gw.fillRect(mX-0.5*mWidth, mY-mHeight, mWidth, mHeight); // X,Y are the coordinates of the bottom center, so subtract to get to the top left corner's coordinates
    for (Disk disk : mDisks) // Range-based for loop that draws all the disks in this peg
    {
        disk.draw(gw);
    }
}

// Add a disk to this peg
void Peg::addDisk(Disk& disk)
{
    mDisks.add(disk); // Add to the end of the vector mDisks
}

// Remove and return the last disk on the peg
Disk Peg::removeDisk()
{
    Disk disk = mDisks[mDisks.size()-1];
    mDisks.remove(mDisks.size()-1);
    return disk;
}

// Get the x coordinate of the bottom center of the peg
int Peg::getX()
{
    return mX;
}

// Get the number of disks on the peg
int Peg::getNumDisks()
{
    return mDisks.size();
}
