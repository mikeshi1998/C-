// ITP 365 Fall 2018
// HW3 Towers of Hannoi
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#pragma once
#include <string>
#include "gwindow.h"

class Disk
{
private:
    int mX; // the x coordinate of the bottom center of the disk
    int mY; // the y coordinate of the bottom center of the disk
    int mWidth; // the width of the disk
    int mHeight; // the height of the disk
    std::string mColor; // the color of the disk
public:
    // Function: Disk
    // Purpose: default constructor
    // Input: none
    // Output: none
    Disk();
    
    // Function: Disk
    // Purpose: constructor that sets the member variables using the inputs
    // Input: the integers of x, y, width and height
    // Output: none
    Disk(int x, int y, int width, int height);
    
    // Function: setX
    // Purpose: set the x coordinate of the bottom center of the disk
    // Input: an integer representing the new x coordinate
    // Output: none
    void setX(int x);
    
    // Function: setY
    // Purpose: set the y coordinate of the bottom center of the disk
    // Input: an integer representing the new y coordinate
    // Output: none
    void setY(int y);
    
    // Function: getHeight
    // Purpose: get the height of the disk
    // Input: none
    // Output: the integer of the height of the disk
    int getHeight();
    
    // Function: draw
    // Purpose: draw the disk
    // Input: the GWindow to draw the disk
    // Output: none
    void draw(GWindow& gw);
};

