// ITP 365 Fall 2018
// HW3 Towers of Hannoi
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include "disk.h"

// Default constructor
Disk::Disk()
{
    mX=400;
    mY=250;
    mWidth=300;
    mHeight=200;
    mColor="black";
}

// Constructor that sets the member variable using the inputs
Disk::Disk(int x, int y, int width, int height)
{
    mX=x;
    mY=y;
    mWidth=width;
    mHeight=height;
    
}

// Set the x coordinate of the bottom center of the disk
void Disk::setX(int x)
{
    mX = x;
}

// Set the y coordinate of the bottom center of the disk
void Disk::setY(int y)
{
    mY = y;
}

// Get the height of the disk
int Disk::getHeight()
{
    return mHeight;
}

void Disk::draw(GWindow& gw)
{
    gw.fillRect(mX-0.5*mWidth, mY-mHeight, mWidth, mHeight); // x, y are the coordinates of the bottom center of the disk, so subtract to get to the upper left corner of the disk
}
