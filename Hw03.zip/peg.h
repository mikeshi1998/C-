// ITP 365 Fall 2018
// HW3 Towers of Hannoi
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#pragma once
#include "vector.h"
#include <string>
#include "disk.h"
#include "gwindow.h"

class Peg
{
private:
    Vector<Disk> mDisks; // a vector of disks storing all the disks all this peg
    int mX; // the x coordinate of the bottom center of the peg
    int mY; // the y coordinate of the bottom center of the peg
    int mWidth; // the width of the peg
    int mHeight; // the height of the peg
    std::string mColor; // the color of the peg
public:
    // Function: Peg
    // Purpose: default constructor
    // Input: none
    // Output: none
    Peg();
    
    // Function: Peg
    // Purpose: constructor, sets the x, y, height, width using the input
    // Input: the integers of x, y, height and width
    // Output: none
    Peg(int x, int y, int height, int width);
    
    // Function: draw
    // Purpose: draw the peg in the GWindow
    // Input: the GWindow to draw the peg
    // Output: none
    void draw(GWindow& gw);
    
    // Function: addDisk
    // Purpose: add a disk to the peg
    // Input: the Disk object to add
    // Output: none
    void addDisk(Disk& disk);
    
    // Function: removeDisk
    // Purpose: remove the last disk on the peg and return it
    // Input: none
    // Output: the last Disk object that is removed
    Disk removeDisk();
    
    // Function: getX
    // Purpose: get the x coordinate of the bottom center of the peg
    // Input: none
    // Output: the x coordinate of the bottom center of the peg
    int getX();
    
    // Function: getNumDisks
    // Purpose: get the number of disks on the peg
    // Input: none
    // Output: an integer representing the number of disks on the peg
    int getNumDisks();
};
