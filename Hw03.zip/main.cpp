// ITP 365 Fall 2018
// HW3 Towers of Hannoi
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include "gwindow.h"
#include "disk.h"
#include "peg.h"

// Function: promptForDisks
// Purpose: ask the user to input the number of disks to start with
// Input: none
// Output: the number of disks to start with
int promptForDisks()
{
    int numDisks;
    std::cout<<"Please enter the number of disks to start with: ";
    std::cin>>numDisks;
    while (numDisks>10 || numDisks<2) // Keep asking the user for input until the user inputs a valid number
    {
        std::cout<<"The valid range is 2 to 10, please enter a valid number: ";
        std::cin>>numDisks;
    }
    return numDisks;
}

// Function: promptForPegs
// Purpose: ask the user to input the starting and ending peg number and then store them into the inputs of the function
// Input: the starting and ending peg number
// Output: none
void promptForPegs(int& start, int& end)
{
    std::cout<<"Please enter a starting peg number: ";
    std::cin>>start;
    while (start > 3 || start < 1) // If the number is not between 1 and 3
    {
        std::cout<<"Please enter a number between 1 to 3: ";
        std::cin>>start;
    }
    std::cout<<"Please enter an ending peg number: ";
    std::cin>>end;
    while (end > 3 || end < 1) // If the number is not between 1 and 3
    {
        std::cout<<"Please enter a number between 1 to 3: ";
        std::cin>>end;
    }
    while (end == start) // If the end and start is the same
    {
        std::cout<<"Please enter an ending number different from the starting number: ";
        std::cin>>end;
        while (end > 3 || end < 1) // If the number is not between 1 and 3
        {
            std::cout<<"Please enter a number between 1 to 3: ";
            std::cin>>end;
        }
    }
}

// Function: draw
// Purpose: clear the GWindow and then draw the current state of the three pegs and the disks on them, then pause for 1 second
// Input: the GWindow to draw and the vector storing the three pegs
// Output: none
void draw(GWindow& gw, Vector<Peg>& pegs)
{
    gw.clear();
    for (Peg peg : pegs)
    {
        peg.draw(gw);
    }
    pause(1000);
}

// Function: moveDisk
// Purpose: move the top disk from the starting peg to the ending peg, set the new x and y coordinates for the moved disk
// Input: the GWindow to draw, the vector of the three pegs, the starting peg number and the ending peg number
// Output: none
void moveDisk(GWindow& gw, Vector<Peg>& pegs, int start, int end)
{
    Disk disk = pegs[start-1].removeDisk(); // Index is the peg number -1
    disk.setX(pegs[end-1].getX()); // Set the new x coordinate for the moved disk align with the ending peg's x coordinate
    disk.setY(500-pegs[end-1].getNumDisks()*40); // Set the new y coordinate according to how many disks are on the ending peg
    pegs[end-1].addDisk(disk);
    draw(gw, pegs);
}

// Function: towerSolver
// Purpose: solve the recursion and gradually move all the disks from the starting peg to the ending peg
// Input: the GWindow to draw, the vector of three pegs, the starting peg number, the ending peg number, and the number of disks to move
// Output: none
void towerSolver(GWindow& gw, Vector<Peg>& pegs, int start, int end, int numDisks)
{
    int temp = 6-start-end; // The other peg's number could be represented by 6-start-end, because the sum of 1,2,3 is always 6
    if (numDisks == 1) // Base case: if there is only one disk to move, just move it from the start peg to the end peg
    {
        moveDisk(gw, pegs, start, end);
    }
    else
    {
        towerSolver(gw, pegs, start, temp, numDisks-1); // If there are n disks, move the top n-1 disks from start to temp, and only leave the bottommost disk on the starting peg
        moveDisk(gw, pegs, start, end); // Move the bottommost disk from start to end
        towerSolver(gw, pegs, temp, end, numDisks-1); // Move the n-1 disks from temp to end so they sit on the bottommost disk
    }
}

int main(int argc, char** argv)
{
    // Create a window
    GWindow gw(800, 500);
    
    int numDisks = promptForDisks(); // Ask the user for number of disks to move
    int start;
    int end;
    promptForPegs(start, end); // Ask the user for the starting and ending peg number
    
    // Create three pegs and store them in a vector called "pegs"
    Peg peg1(150, 500, 10, 450);
    Peg peg2(400, 500, 10, 450);
    Peg peg3(650, 500, 10, 450);
    Vector<Peg> pegs;
    pegs.add(peg1);
    pegs.add(peg2);
    pegs.add(peg3);
    
    // Create a number of disks according to the total number of disks to move and then place them on the starting peg
    for (int i=0; i<numDisks; i++)
    {
        Disk addDisk(pegs[start-1].getX(), 500-40*i, 200-16*i, 40); // x coordinate of the disks and the starting peg is the same, decrease y by 40 each time after adding a disk, decrease width by 16 each time after adding a disk
        pegs[start-1].addDisk(addDisk);
    }
    
    draw(gw, pegs); // Draw the initial state
    

    towerSolver(gw, pegs, start, end, numDisks); // Call the recursion to start the recursive solution

    
    return 0;
}

