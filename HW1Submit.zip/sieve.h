// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// ITP 365 Fall 2018
// HW1 – Sieve of Eratosthenes
// Platform: Mac

#pragma once
#include "gwindow.h"


// Create an enum that has three variables: UNKNOWN, PRIME, COMPOSITE
enum NumberType
{
    UNKNOWN,
    PRIME,
    COMPOSITE,
};

// Function: drawSquare
// Purpose: Draw a 50*50 square based on the input information
// Input: The window to draw, the number to display in the center, the type of the number, the x-coordinate of the top-left corner, the y-coordinate of the top-left corner
// Output: Returns void
void drawSquare(GWindow& gw, int number, enum NumberType, double X, double Y);

// Function: initVectors
// Purpose: Initialize the two vectors to their initial states
// Input: A vector of ints, a vector of NumberTypes
// Output: Returns void
void initVectors(Vector<int>& ints, Vector<NumberType>& numTypes);

// Function: drawGrid
// Purpose: Drawing the current state of the grid
// Input: The window to draw, the vector of ints, the vector of NumberTypes
// Output: Returns void
void drawGrid(GWindow& gw, Vector<int>& numbers, Vector<NumberType>& types);

// Function: calcNextPrime
// Purpose: Find the next prime number and mark its multiples as composite
// Input: The vector of ints, the vector of NumberTypes, the number to start testing at
// Output: Return the prime number that was found, or -1 if there are no prime number left
int calcNextPrime(Vector<int>& ints, Vector<NumberType>& numTypes, int startAt);
