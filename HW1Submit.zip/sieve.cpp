// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// ITP 365 Fall 2018
// HW1 – Sieve of Eratosthenes
// Platform: Mac

#include "sieve.h"
#include "gwindow.h"
#include <string>
#include "strlib.h"
#include <iostream>

void drawSquare(GWindow& gw, int number, NumberType type, double X, double Y)
{
    // If the number type is UNKNOWN, draw the square in white
    if (type == UNKNOWN)
    {
        gw.setColor("white");
        gw.fillRect(X, Y, 50, 50);
        gw.setColor("black");
        gw.drawRect(X, Y, 50, 50);
        std::string num = integerToString(number);
        gw.drawLabel(num, X+25, Y+25);
    }
    // If the number type is PRIME, draw the square in green
    else if (type == PRIME)
    {
        gw.setColor("green");
        gw.fillRect(X, Y, 50, 50);
        gw.setColor("black");
        gw.drawRect(X, Y, 50, 50);
        std::string num = integerToString(number);
        gw.drawLabel(num, X+25, Y+25);
    }
    // If the number type is COMPOSITE, draw the square in red
    else if (type == COMPOSITE)
    {
        gw.setColor("red");
        gw.fillRect(X, Y, 50, 50);
        gw.setColor("black");
        gw.drawRect(X, Y, 50, 50);
        std::string num = integerToString(number);
        gw.drawLabel(num, X+25, Y+25);
    }
    
}

void initVectors(Vector<int>& ints, Vector<NumberType>& numTypes)
{
    // Store numbers from 2 to 101 in the vector ints
    for (int i = 2; i <= 101; i++)
    {
        ints.add(i);
    }
    // Store 100 UNKNOWN in the vector numTypes
    NumberType type = UNKNOWN;
    for (int i = 0; i < 100; i++)
    {
        numTypes.add(type);
    }
}


void drawGrid(GWindow& gw, Vector<int>& numbers, Vector<NumberType>& types)
{
    // Start drawing from the upper left corner
    int x = 0;
    int y = 0;
    for (int i =0; i <= 99; i++)
    {
        drawSquare(gw, numbers[i], types[i], x, y);
        // Increase x by 50 after drawing a square
        x += 50;
        // If x is larger than 450, we are at the end of the row, so set x back to 0 and increase y by 50
        if (x > 450)
        {
            x = 0;
            y += 50;
        }
    }
}


int calcNextPrime(Vector<int>& ints, Vector<NumberType>& numTypes, int startAt)
{
    for (int i = startAt; i < numTypes.size(); i++)
    {
        // The first index that is marked as UNKNOWN must be a prime number
        if (numTypes[i] == UNKNOWN)
        {
            numTypes[i] = PRIME;
            // Every multiple of this number should be marked COMPOSITE
            for (int j = i + 1; j < numTypes.size(); j++)
            {
                if (ints[j]%ints[i] == 0)
                {
                    numTypes[j] = COMPOSITE;
                }
            }
            // Return the prime number and exit the for loop since we are finding one prime number at a time
            return ints[i];
            break;
        }
        
    }
    // Return -1 if no UNKNOWN is left
    return -1;
}



