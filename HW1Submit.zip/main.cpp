// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// ITP 365 Fall 2018
// HW1 – Sieve of Eratosthenes
// Platform: Mac

#include "gwindow.h"
#include "sieve.h"
#include "vector.h"


int main(int argc, char** argv)
{
    // Create a 500x500 window
    GWindow gw(500, 500);
    
    // TODO: Implement stuff
    
    // Create a vector of ints that store the numbers from 2 to 101, and another vector of NumberTyes that we use to flag which number is prime or composite
    Vector<int> ints;
    Vector<NumberType> numTypes;
    initVectors(ints, numTypes);
    // Find the first prime
    int result = calcNextPrime(ints, numTypes, 0);
    while (result != -1)
    {
        // Draw the current state of the grid and then find the next prime
        drawGrid(gw, ints, numTypes);
        result = calcNextPrime(ints, numTypes, 0);
        pause(1000.0);
        
    }
    
    
    return 0;
}



