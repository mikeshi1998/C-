// ITP 365 Spring 2018
// HW7 - IMDB Graph
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac
//
// IDMBData.cpp - Implements IMDBData interface

#include "IMDBData.h"
#include <fstream>
#include <iostream>
#include <queue>

// Do for Part 1
// Function: Default Constructor
// Purpose: Loads in the actor/movie file specified,
// and populates the data into the appropriate hash maps.
// Also constructs the graph with actor relationships.
// Input: Name of file to load (by reference)
// Returns: Nothing
IMDBData::IMDBData(const std::string& fileName)
{
    // Open the file for reading
    std::ifstream inFile(fileName);
    
    if (!inFile.is_open())
    {
        std::cout<<"File \"" + fileName + "\" not found!" <<std::endl;
        
    }
    std::string line;
    std::string actorName;
    std::string movieName;
    std::vector<std::string> movies;
    // Grab the first actor's name...
    std::getline(inFile, actorName);
    
    // Loop over file contents
    while (!inFile.eof())
    {
        // Grab a line of text!
        std::getline(inFile, line);
        // If it is an empty line
        if (line.length() == 0)
        {
            // If the old actor is not in the map yet
            auto itr = mActorsToMoviesMap.find(actorName);
            if (itr == mActorsToMoviesMap.end())
            {
                // Save the old actor/actress information
                mActorsToMoviesMap[actorName] = movies;
                
                // I've got a complete actor/movie set..
                // Call reverse map here!
                reverseMap(actorName, movies);
            }
        }
        // Is it a movie?
        else if (line[0] == '|')
        {
            // Grab the title
            movieName = line.substr(1);
            // Add it to the movie vector
            movies.push_back(movieName);
        }
        else
        {
            // We've got an actor or actress
            // If the old actor is not in the map yet
            auto itr = mActorsToMoviesMap.find(actorName);
            if (itr == mActorsToMoviesMap.end())
            {
                // Save the old actor/actress information
                mActorsToMoviesMap[actorName] = movies;
                
                // I've got a complete actor/movie set..
                // Call reverse map here!
                reverseMap(actorName, movies);
            }
            // Prep for new actor info
            actorName = line;
            movies.clear();
            
        }
    }
}

// Do for Part 1
// Function: reverseMap
// Purpose: This is a helper function that is used to generate
// the reverse map (movies to actors)
// Input: Name of actor (by reference), vector of their movies (by reference)
// Returns: Nothing
void IMDBData::reverseMap(const std::string& actorName, const std::vector<std::string>& movies)
{
	// Iterate over all the movies in the vector
    for (std::string movieName : movies)
    {
        // Check to see if the movie is already in the map...
        auto itr = mMoviesToActorsMap.find(movieName);
        
        if (itr != mMoviesToActorsMap.end())
        {
            // The movie already has an entry in the map!
            // Add the actor to the movie's vector of actors
            itr->second.push_back(actorName);
            
        }
        else
        {
            // The movie isn't in the map yet...
            // Add it and a new vector!
            std::vector<std::string> actors;
            actors.push_back(actorName);
            mMoviesToActorsMap[movieName] = actors;
            
        }
    }
}

// Do for Part 1
// Function: getMoviesFromActor
// Purpose: Given an actor's name, returns a vector containing their movies
// Input: Name of actor (by reference)
// Returns: Vector of movies (by reference)
std::vector<std::string>& IMDBData::getMoviesFromActor(const std::string& actorName)
{
    auto itr = mActorsToMoviesMap.find(actorName);
	if (itr != mActorsToMoviesMap.end())
    {
        // We found the actor!
        return itr->second;
    }
	return sEmptyVector;
}

// Do for Part 1
// Function: getActorsFromMovie
// Purpose: Given a movie's name, returns the name of its actors
// Input: Name of movie (by reference)
// Returns: Vector of actors (by reference)
std::vector<std::string>& IMDBData::getActorsFromMovie(const std::string& movieName)
{
    auto itr = mMoviesToActorsMap.find(movieName);
    if (itr != mMoviesToActorsMap.end())
    {
        // We found the movie！
        return itr->second;
    }
	return sEmptyVector;
}

// Do for Part 2
// Function: findRelationship
// Purpose: Tries to find a relationship between two actors, using a BFS
// and outputs (to cout) the result of the search.
// Input: Name of two actors to check for a relationship
// Returns: Nothing
void IMDBData::findRelationship(const std::string& fromActor, const std::string& toActor)
{
    // check that the two actors passed to findRelationship are in the graph
    if (mGraph.containsActor(fromActor) && mGraph.containsActor(toActor))
    {
        // Create a queue of ActorNode*, and enqueue the node we’re starting from...
        std::queue<ActorNode*> bfsQueue;
        bool found = false;
        ActorNode* begin = mGraph.getActorNode(fromActor);
        bfsQueue.push(begin);
        // While the BFS queue is not empty...
        while (!bfsQueue.empty())
        {
            // Dequeue the front ActorNode*, and save in currentNode
            ActorNode* currentNode = bfsQueue.front();
            bfsQueue.pop();
            // If currentNode == targetNode, we found a path!
            if (currentNode->mName == toActor)
            {
                found = true;
                break;
            }
            // Otherwise if currentNode’s visited bool is false...
            else
            {
                if (!currentNode->mIsVisited)
                {
                    // Set currentNode visited to true
                    currentNode->mIsVisited = true;
                    // Loop through currentNode’s adjacency list
                    for (Edge* movie : currentNode->mEdges)
                    {
                        // If the visited flag is false...
                        if (!movie->mOtherActor->mIsVisited)
                        {
                            // Enqueue the adjacent node
                            bfsQueue.push(movie->mOtherActor);
                            // If the adjacent node path has a size of 0...
                            if (movie->mOtherActor->mPath.empty())
                            {
                                // Set the adjacent node’s path equal to currentNode’s path
                                movie->mOtherActor->mPath = currentNode->mPath;
                                // Push_back adjacent nodes’s relevant path information
                                movie->mOtherActor->mPath.push_back(PathPair(movie->mMovieName,movie->mOtherActor->mName));
                            }
                        }
                    }
                }
            }
        
        }
        if (found) // If we found a path
        {
            ActorNode* toActorNode = mGraph.getActorNode(toActor);
            std::cout<<"Found a path! ("<<toActorNode->mPath.size()<<" hops)"<<std::endl;
            std::cout<<fromActor<<" was in..."<<std::endl;
            auto itr = toActorNode->mPath.begin();
            for (const PathPair& path : toActorNode->mPath) // Loop through all the PathPair in the target node's mPath
            {
                
                itr++;
                // If it is not the last path, cout the movie name, actor name and "who was in" to connect to the next path
                if (itr!=toActorNode->mPath.end())
                {
                    std::cout<<path.getMovieName()<<" with "<<path.getActorName()<<" who was in "<<std::endl;
                }
                // If it is the last path, don't cout the "who was in"
                else
                {
                    std::cout<<path.getMovieName()<<" with "<<path.getActorName()<<std::endl;
                }
            }
        }
        else // If we didn't find a path
        {
            std::cout<<"Didn't find a path."<<std::endl;
        }
    
    }
    else // If the actors are not in the graph
    {
        std::cout<<"Actors not in the graph!"<<std::endl;
    }
	// LEAVE THIS AT THE END OF THE FUNCTION
	mGraph.clearVisited();
}

// For Part 2
// Function: createGraph
// Purpose: This helper function constructs the IMDBGraph from the movie to actors map
// Input: None
// Returns: Nothing
void IMDBData::createGraph()
{
	// DO NOT EDIT THIS FUNCTION
	// For every movie in the actors map...
	for (auto& p : mMoviesToActorsMap)
	{
		const std::string& movieName = p.first;
		// Get the actors for this movie
		const std::vector<std::string>& actors = mMoviesToActorsMap[movieName];

		// Make n^2 edges between these actors
		for (size_t i = 0; i < actors.size(); i++)
		{
			ActorNode* firstActor = mGraph.getActorNode(actors[i]);
			for (size_t j = i + 1; j < actors.size(); j++)
			{
				ActorNode* secondActor = mGraph.getActorNode(actors[j]);
				mGraph.createActorEdge(firstActor, secondActor, movieName);
			}
		}
	}
}

// Leave here! Do not edit!!! Use in part 1
// DO NOT REMOVE THIS LINE
std::vector<std::string> IMDBData::sEmptyVector;
