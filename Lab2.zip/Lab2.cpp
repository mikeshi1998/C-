// ITP 365 Spring 2018
// Lab02
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include "vector.h"
#include "strlib.h"

int main(int argc, char** argv)
{
    Vector<std::string> sonnets;
    std::string fname = "";
    
    //Prompt for input
    std::cout << "Where's Shakespear's stuff: ";
    std::cin >> fname;
    
    // Open the file, and check for bad file
    std::ifstream sfile(fname);
    if (!sfile.is_open())
    {
        std::cout << "ERROR: File \"" << fname<< "\" doesn't exist!" << std::endl;
        return -1;
    }
    
    // Read in the shakespear file...
    while (!sfile.eof()){
        // Grab a line of text
        std::string shakeLine;
        std::getline(sfile, shakeLine);
        
        // ID the beginning of the sonnets...
        if (shakeLine.find("THE SONNETS") != std::string::npos)
        {
            // We found the sonnets!
            //std::cout<<"Found the beginning of the sonnets!"<<std::endl;
            // Get rid of 2 lines
            std::getline(sfile, shakeLine);
            std::getline(sfile, shakeLine);
            
            // Loop until we find the end...
            while (!sfile.eof()){
                std::string sonnetLine;
                std::getline(sfile, sonnetLine);
                
                // Look for a number!
                if (stringIsInteger(sonnetLine))
                {
                    // We found a number! Lets grab a sonnet!
                    //std::cout << "Found #" << trim(sonnetLine) << std::endl;
                    
                    std::ostringstream wholeSonnet;
                    
                    
                    // Grab a whole sonnet!
                    while (!sfile.eof())
                    {
                        // Get a line from the sonnet
                        std::string stext;
                        std::getline(sfile, stext);
                        
                        wholeSonnet << stext << std::endl;
                        
                        if (trim(stext).size() == 0)
                        {
                            // We found an empty line
                            // Stop reading a sonnet!
                            sonnets.add(wholeSonnet.str());
                            break;
                        }
                    }
                }
                
                // Check for the end of the sonnets
                if (sonnetLine.find("THE END")!=std::string::npos)
                {
                    // We found the end of the sonnets!
                    //std::cout << "Found the end of the sonnets!" << std::endl;
                    break;
                }
            }
            
        } // End loop to find sonnets
    } // End file reading loop
    
    // Interact with the user...
    std::cout << "Just loaded " << sonnets.size() << " sonnets" << std::endl;
    std::cin.ignore();
    // Input loop...
    while (true)
    {
        // Get user input
        std::string userInput;
        std::cout << "What sonnet would you like? ";
        std::getline(std::cin, userInput);
        // Get rid of extra whitespace
        userInput=trim(userInput);
        
        if (stringIsInteger(userInput))
        {
            // We've got good input
            //Convert the number
            int userNum=stringToInteger(userInput);
            if (userNum < 1)
            {
                // Quit asking for input
                break;
            }
            else if (userNum > sonnets.size())
            {
                // Number was too big!
                std::cout<<"Please enter a number between 1 and " << sonnets.size() << std::endl;
            }
            else
            {
                std::cout<<"Sonnet #" << userNum<<std::endl;
                std::cout <<sonnets[userNum-1] <<std::endl;
            }
        }
        else
        {
            // bad input
            std::cout<<"Please enter a number between 1 and " << sonnets.size() << std::endl;
        }
        
    } // End input loop
    
    return 0;
}
