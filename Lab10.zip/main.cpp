// ITP 365 Fall 2018
// LP10 – Timings (part 3)
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include <map>
#include <unordered_map>
#include <iostream>
#include <chrono>

int main()
{
    long long int stopNum = -1;
    std::cout << "Where shall I stop counting?\n> ";
    std::cin >> stopNum;
    
    std::map<long long int, double> map;
    std::unordered_map<long long int, double> hashMap;
    
    std::chrono::time_point<std::chrono::system_clock> timeStart, timeEnd;
    std::chrono::duration<double> elapsedTime;
    
    // Map insert
    std::cout<<"\nMap insert..."<<std::endl;
    timeStart = std::chrono::system_clock::now();
    for (long long int i = 0; i<stopNum; i++)
    {
        map[i]=i*2.0;
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout <<"...took "<<elapsedTime.count() << " s" << std::endl;
    
    // Map lookup
    std::cout<<"\nMap lookup..."<<std::endl;
    timeStart = std::chrono::system_clock::now();
    for (long long int i = -stopNum; i<stopNum; i++)
    {
        auto mitr = map.find(i);
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout <<"...took "<<elapsedTime.count() << " s" << std::endl;
    
    // Map lookup and remove
    std::cout<<"\nMap lookup and remove..."<<std::endl;
    timeStart = std::chrono::system_clock::now();
    for (long long int i = 2*stopNum; i>0; i--)
    {
        auto remItr = map.find(i);
        if (remItr != map.end())
        {
            map.erase(remItr);
        }
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout <<"...took "<<elapsedTime.count() << " s" << std::endl;

    // Hash map insert
    std::cout<<"\nHash map insert..."<<std::endl;
    timeStart = std::chrono::system_clock::now();
    for (long long int i = 0; i<stopNum; i++)
    {
        hashMap[i]=i*2.0;
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout <<"...took "<<elapsedTime.count() << " s" << std::endl;
    
    // Hash map lookup
    std::cout<<"\nHash map lookup..."<<std::endl;
    timeStart = std::chrono::system_clock::now();
    for (long long int i = -stopNum; i<stopNum; i++)
    {
        auto hmitr = hashMap.find(i);
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout <<"...took "<<elapsedTime.count() << " s" << std::endl;

    // Hash map lookup and remove
    std::cout<<"\nHash map lookup and remove..."<<std::endl;
    timeStart = std::chrono::system_clock::now();
    for (long long int i = 2*stopNum; i>0; i--)
    {
        auto remHmItr = hashMap.find(i);
        if (remHmItr != hashMap.end())
        {
            hashMap.erase(remHmItr);
        }
    }
    timeEnd = std::chrono::system_clock::now();
    elapsedTime = timeEnd - timeStart;
    std::cout <<"...took "<<elapsedTime.count() << " s" << std::endl;

    return 0;
}


