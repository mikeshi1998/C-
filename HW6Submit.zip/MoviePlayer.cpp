// ITP 365 Fall 2018
// HW6 - Doubly Linked List and Movie Player
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include "MoviePlayer.h"

// Function: Parameterized Constructor
// Purpose: Sets member variables to input, clears list, and calls loader
// Input: None
// Returns: Nothing
MoviePlayer::MoviePlayer(std::string filmName)
{
    mFilmName = filmName;
    mFilm.clear();
    loadTape();
}

// Function: Destructor
// Purpose: Empties the list
// Input: None
// Returns: Nothing
MoviePlayer::~MoviePlayer()
{
    mFilm.clear();
}

// Function: goFwrd
// Purpose: Moves the current "frame" forward by 1 frame
// Also keeps track of how many frames have been viewed
// Shouldn't go past the end of the movie
// Input: None
// Returns: Nothing
void MoviePlayer::goFwrd()
{
    // If the next node is not a null pointer, we can move to the next
    if (pos->mNext != nullptr)
    {
        pos++; // Move the iterator forward
        currFrameNum++; // Increment the current frame number
    }
}

// Function: goBack
// Purpose: Moves the current "frame" backward by 1 frame
// Also keeps track of how many frames have been viewed
// Shouldn't go past the end of the movie
// Input: None
// Returns: Nothing
void MoviePlayer::goBack()
{
    // If the previous node is not a null pointer, we can move to the previous
    if (pos->mPrev != nullptr)
    {
        pos--; // Move the iterator backward
        currFrameNum--; // Decrement the current frame number
    }
}

// Function: rewind
// Purpose: Moves the current "frame" to the movie's beginning again
// Input: None
// Returns: Nothing
void MoviePlayer::rewind()
{
    currFrameNum = 1; // Change the current frame number to be 1
    pos = mFilm.begin(); // Move the iterator to pointing to the beginning frame
}

// Function: getCurrFrame
// Purpose: Gets the string that contains the current "frame" as stored
// in the list "mFilm"
// Input: None
// Returns: String with the current "frame"
std::string MoviePlayer::getCurrFrame()
{
    return *pos; // Dereference the iterator and get the string stored in this node
}

// Function: delCurrFrame
// Purpose: Deletes the current frame, moves forward to the next one
// Also keeps track of how many frames have been viewed
// Input: None
// Returns: Nothing
void MoviePlayer::delCurrFrame()
{
    pos = mFilm.erase(pos); // Delete the current node and move the iterator forward
    
}

// Function: copyCurrFrame
// Purpose: Copies current frame and places the copy BEFORE the current frame
// Also keeps track of how many frames have been viewed
// Input: None
// Returns: Nothing
void MoviePlayer::copyCurrFrame()
{
    pos = mFilm.insert(pos, *pos); // Insert a copy of the current frame before the current frame, make the iterator pointing to the inserted frame
}

// Function: getCurrFrameNum
// Purpose: Gets the "index" that corresponds to the current frame
// Input: None
// Returns: Number of frames that have been viewed
unsigned MoviePlayer::getCurrFrameNum() const
{
    return currFrameNum;
}

// Function: getNumFrames
// Purpose: Gets the total number of frames in the movie
// Input: None
// Returns: The overall number of frames in the movie
unsigned int MoviePlayer::getNumFrames() const
{
    return mFilm.size();
}

// Function: getFrameSize
// Purpose: Gives the number of lines in a frame
// For how big the "screen" for the film should be
// Input: None
// Returns: The value stored in FRAMESIZE
unsigned int MoviePlayer::getFrameSize() const
{
    return FRAMESIZE;
}

// Function: getCurrFrame
// Purpose: Retrieves the current "frame" from the film list
// Modifies the inputted vector of GLabels to contain the current frame
// Input: A vector of "GLabels" that are the "screen" -- passed by reference
// Returns: Nothing
void MoviePlayer::getCurrFrame(Vector<GLabel*>& screen)
{
    std::string copy = *pos; // Create a copy of the string in the current frame
    for (int i = 0; i < screen.size(); i++)
    {
        unsigned long index = copy.find("\n");
        std::string line = copy.substr(0, index); // Get the i th line
        screen[i]->setLabel(line); // Store the i th line in the i th element of the vector
        copy.erase(0, index+1); // Erase the current line so that in the for loop, the next iteration will deal with the next line
    }
}

// Function: loadTape
// Purpose: Uses mFilmName (set by constructor) to fill
// mFilm with strings that make up the movie to display
// Input: None
// Returns: Nothing
void MoviePlayer::loadTape()
{
    std::ifstream fileInput(mFilmName);
    if (fileInput.is_open())
    {
        while (!fileInput.eof())
        {
            std::string line;
            std::getline(fileInput, line);
            if (line.length()!=0) // If the line is not empty
            {
                if (stringIsInteger(line)) // If the line is a number, it is the number of times this frame should be displayed
                {
                    int times = stringToInteger(line);
                    std::ostringstream wholeFrame; // Create an output string stream to hold the 13 lines
                    for (int i = 0; i<13; i++)
                    {
                        std::string text;
                        std::getline(fileInput, text);
                        wholeFrame<<text<<" "<<std::endl; // Add a white space at the end of each line and go to the next line
                    }
                    for (int i =0; i<times; i++) // Add this frame to mFilm the number of times it should be displayed
                    {
                        mFilm.push_back(wholeFrame.str());
                    }
                }
            }
        }
    }
    else
    {
        error("File not found!");
    }
}
