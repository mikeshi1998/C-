// ITP 365 Fall 2018
// HW4 - Wedding Planner
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include "hevent.h"
#include "hcal.h"
#include "dateconv.h"
#include <iostream>
#include <string>
#include <fstream>
#include "strlib.h"

// Function: loadCal
// Purpose: read in the .csv file, create the appropriate holiday events, and load them into a calendar
// Input: a string holding the file's name
// Output: a pointer to the HCal that stores the holiday event
HCal* loadCal(const std::string& fileName)
{
    HCal* calPtr = new HCal; // Dynamically create an HCal
    std::ifstream fileInput(fileName);
    std::string line;
    std::getline(fileInput, line); // Get rid of the first line which are the variables' names
    while (!fileInput.eof()) // Loop through the file
    {
        std::getline(fileInput, line);
        // If we reach the last line which has no data, just exit the while loop whithout storing any variable
        if (trim(line).size()==0)
        {
            break;
        }
        unsigned long long epoch = std::stoull(line.substr(0, 10)); // The first 10 characters are the epoch time, convert them to an unsigned long long
        std::string holiday = line.substr(11); // Everything after the 12th character is stored as the holiday's day and name
        HEvent* holidayPtr = new HEvent(epoch, holiday); // Dynamically create a HEvent with the epoch time and holiday information we get
        calPtr->addEvent(holidayPtr); // Add the pointer to the HCal we created
    }
    return calPtr; // Return the HCal holding pointers to the HEvents we get from the file
}

// Function: merge
// Purpose: merge two HCal into one
// Input: two pointers to the HCals we want to merge
// Output: a pointer to the merged HCal
HCal* merge(HCal* a, HCal* b)
{
    HCal* c = new HCal; // Dynamically create a new HCal
    unsigned int i=0; // Index i to count through HCal a
    unsigned int j=0; // Index j to count through HCal b
    while (i<a->getSize() && j<b->getSize()) //  While i and j are both within range of their respective calendars
    {
        // If the HEvent at a[i] occurs before the HEvent at b[j] add a[i] to the end of c
        if(*(a->getEvent(i)) < *(b->getEvent(j)))
        {
            c->addEvent(a->getEvent(i));
            i++; // Increment i
        }
        // Otherwise add the event at b[j] to the end of c
        else
        {
            c->addEvent(b->getEvent(j));
            j++; // Increment j
        }
    }
    if (i!=a->getSize()) // If a is left over
    {
        for (; i<a->getSize(); i++) // Add the remaining items to the end of c
        {
            c->addEvent(a->getEvent(i));
        }
    }
    else if (j!=b->getSize()) // If b is left over
    {
        for (; j<b->getSize(); j++) // Add the remaining items to the end of c
        {
            c->addEvent(b->getEvent(j));
        }
    }
    return c; // Return the pointer to the merged HCal
}


int main(int argc, char** argv)
{
	// Read in all data files
    HCal* calPtr = loadCal("CHholiday2016.csv");
    HCal* calPtr2 = loadCal("USholiday2016.csv");
    HCal* calPtr3 = loadCal("BRholiday2016.csv");
    HCal* mergePtr = merge(calPtr, calPtr2);
    HCal* finalCal = merge(mergePtr, calPtr3); // Merge the three calendars
    std::cout<<"Welcome to the wedding planner!\n"<<std::endl;
    std::string input;
    std::cout<<"Please enter a date (MM/DD/YYYY): ";
    std::cin>>input;
    while (input != "q" && input != "Q") // If the user inputs q or Q, exit
    {
        unsigned long long index1 = input.find("/", 0);
        unsigned long long index2 = input.find("/", index1+1);
        if (index1!=std::string::npos && index2!=std::string::npos) // Check if the user input has the correct format, there needs to be two "/"
        {
            std::string monthStr = input.substr(0, index1); // Input before the first "/" is the month
            std::string dayStr = input.substr(index1+1, index2-index1-1); // Input from the first "/" to the second "/" is the day
            std::string yearStr = input.substr(index2+1, 4); // Input after the second "/" is the year
            unsigned int month = stringToInteger(monthStr);
            unsigned int day = stringToInteger(dayStr);
            unsigned int year = stringToInteger(yearStr);
            unsigned long long epoch = getEpochSecs(month, day, year);
            unsigned long long adjustedEpoch;
            // Adjust the epoch seconds to GMT based on the date
            if (month>3 && month<11 ) // From April to October, PST and GMT has a 7 hours difference
            {
                adjustedEpoch = epoch - 25200;
            }
            else if (month==3 && day>=14) // From March 14th to the end of March, PST and GMT also has a 7 hour difference
            {
                adjustedEpoch = epoch - 25200;
            }
            else if (month==11 && day<=6) // From November 1st to November 6th, PST and GMT also has a 7 hour difference
            {
                adjustedEpoch = epoch - 25200;
            }
            else // Otherwise, PST and GMT has a 8 hour difference
            {
                adjustedEpoch = epoch - 28800;
            }
            HEvent* event = new HEvent(adjustedEpoch, "a day"); // Dynamically create an HEvent based on the converted epoch seconds
            int searchIndex = finalCal->search(event); // Search through the merged calendar
            // If we didn't find any holiday at this date, it would be a great day for a wedding
            if (searchIndex == -1)
            {
                std::cout<<"That's a great day for a wedding!"<<std::endl;
            }
            // If we find a holiday at this date, display the information about this holiday
            else
            {
                std::cout<<*(finalCal->getEvent(searchIndex))<<std::endl;
            }
            std::cout<<"\nPlease enter a date (MM/DD/YYYY): ";
            std::cin>>input;
        }
        // If the input has incorrect format, ask the user to enter again
        else
        {
            std::cout<<"Invalid date. Please enter again. ";
            std::cin>>input;
        }

    }
    std::cout<<"Quitting!"<<std::endl;
	return 0;
}

