// ITP 365 Fall 2018
// HW4 - Wedding Planner
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include "hevent.h"
#include "dateconv.h"

// Parameterized constructor
HEvent::HEvent(unsigned long long epoch, const std::string& holiday)
{
    // Set the member variable to the input
    mEpoch=epoch;
    mHoliday=holiday;
}

// Test whether left occurs before right
bool operator<(const HEvent& left, const HEvent& right)
{
    if (left.mEpoch < right.mEpoch)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// Test whether left occurs after right
bool operator>(const HEvent& left, const HEvent& right)
{
    if (left.mEpoch > right.mEpoch)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// Test whether left and right occurs at the same time
bool operator==(const HEvent& left, const HEvent& right)
{
    if (left.mEpoch == right.mEpoch)
    {
        return true;
    }
    else
    {
        return false;
    }
}

std::ostream& operator<<(std::ostream& os, const HEvent& event)
{
    // Display the date in MM/DD/YYYY format and the holiday event's day and name
    os<<getMonth(event.mEpoch)<<"/"<<getMonthDay(event.mEpoch)<<"/"<<getYear(event.mEpoch)<<" is "<<event.mHoliday;
    return os;
}

