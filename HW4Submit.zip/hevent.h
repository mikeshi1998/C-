// ITP 365 Fall 2018
// HW4 - Wedding Planner
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#pragma once
#include <string>
#include <iostream>

// One HEvent class object is a holiday event
class HEvent
{
private:
    unsigned long long mEpoch; // epoch time of the holiday
    std::string mHoliday; // the holiday's name
public:
    // Function: HEvent
    // Purpose: constructor
    // Input: an unsigned long long of epoch time and a string of the holiday's name
    // Output: none
    HEvent(unsigned long long epoch, const std::string& holiday);
    
    // Function: operator<
    // Purpose: overload the operator< to set up a comparator for HEvent
    // Input: two HEvents to compare
    // Output: a boolean representing the result of the comparison
    friend bool operator<(const HEvent& left, const HEvent& right);
    
    // Function: operator>
    // Purpose: overload the operator> to set up a comparator for HEvent
    // Input: two HEvents to compare
    // Output: a boolean representing the result of the comparison
    friend bool operator>(const HEvent& left, const HEvent& right);
    
    // Function: operator==
    // Purpose: overload the operator== to set up a comparator for HEvent
    // Input: two HEvents to compare
    // Output: a boolean representing the result of the comparison
    friend bool operator==(const HEvent& left, const HEvent& right);
    
    // Function: opeartor<<
    // Purpose: overload the operator<< to cout information about the holiday event
    // Input: the output stream and an HEvent
    // Output: an output stream with information about the HEvent
    friend std::ostream& operator<<(std::ostream& os, const HEvent& event);
};

