// ITP 365 Fall 2018
// HW4 - Wedding Planner
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#include "hcal.h"

// Default constructor
HCal::HCal()
{
    mHevent.clear(); // Clear the std::vector
}

void HCal::addEvent(HEvent* event)
{
    mHevent.push_back(event); // Add the HEvent pointer to the end of the vector
}

size_t HCal::getSize()
{
    return mHevent.size(); // Get the size of the vector
}

HEvent* HCal::getEvent(unsigned int index)
{
    return mHevent[index]; // Get the HEvent pointer based on inputted index
}

int HCal::binarySearchPart(std::vector<HEvent*>& vec, HEvent* event, int start, int end)
{
    // If we didn't find the HEvent, return -1
    if (end < start)
    {
        return -1;
    }
    int middleIndex = (end + start) / 2; // Find the middle index
    // If the middle index corresponds to the pointer to the HEvent that we are looking for, return this middle index
    if (*(vec[middleIndex]) == *event)
    {
        return middleIndex;
    }
    // If the value at the middle is larger than the value we are looking for, binary search the first half
    if (*(vec[middleIndex]) > *event)
    {
        return binarySearchPart(vec, event, start, middleIndex - 1);
    }
    // If the value at the middle is smaller than the value we are looking for, binary search the second half
    else
    {
        return binarySearchPart(vec, event, middleIndex + 1, end);
    }
}

int HCal::search(HEvent* event)
{
    // Return the value we got from the helper function binarySearchPart
    return binarySearchPart(mHevent, event, 0, getSize());
}
