// ITP 365 Fall 2018
// HW4 - Wedding Planner
// Name: Yuchen Shi
// Email: yuchensh@usc.edu
// Platform: Mac

#pragma once
#include <iostream>
#include <vector>
#include "hevent.h"

class HCal
{
private:
    std::vector<HEvent*> mHevent; // A std::vector holding HEvent pointers
    
    // Function: binarySearchPart
    // Purpose: a helper function for the binary search
    // Input: the std::vectors of HEvent to search through, the pointer to the HEvent that we are searching for, an int representing the first index and an int representing the last index
    // Output: an int representing the index of the HEvent pointer we want
    int binarySearchPart(std::vector<HEvent*>& vec, HEvent* event, int start, int end);
public:
    // Function: HCal
    // Purpose: default constructor
    // Input: none
    // Output: none
    HCal();
    
    // Function: addEvent
    // Purpose: add an HEvent pointer to the end of the std::vector mHevent
    // Input: the HEvent pointer to add
    // Output: none
    void addEvent(HEvent* event);
    
    // Function: getSize
    // Purpose: get the size of the std::vector mHevent
    // Input: none
    // Output: a size_t representing the size of the vector
    size_t getSize();
    
    // Function: getEvent
    // Purpose: get the HEvent pointer based on the index
    // Input: an unsigned int representing the index of the HEvent pointer we want
    // Output: the HEvent pointer that we want
    HEvent* getEvent(unsigned int index);
    
    // Function: search
    // Purpose: Perform a binary search algorithm to check if a HEvent is in the HCal
    // Input: a pointer to the HEvent that we are looking for
    // Output: an int representing the index of the HEvent we want or -1 representing we didn't find any holiday event
    int search(HEvent* event);
};
